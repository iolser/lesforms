from django.apps import AppConfig


class PreEventsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pre_events'
