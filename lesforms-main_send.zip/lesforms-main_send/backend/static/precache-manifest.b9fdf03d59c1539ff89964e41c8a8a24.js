self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "187ea65152583fce7ec6",
    "url": "/static/css/app.b33a3d3c.css"
  },
  {
    "revision": "d06d77014af57f5e08b072284a934f64",
    "url": "/static/index.html"
  },
  {
    "revision": "187ea65152583fce7ec6",
    "url": "/static/js/app.9ca02b0d.js"
  },
  {
    "revision": "0d6dd6e592290e7fe927",
    "url": "/static/js/chunk-vendors.d54be52e.js"
  },
  {
    "revision": "4b14c64efaf846819b9a229b4193c8b7",
    "url": "/static/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/static/robots.txt"
  }
]);