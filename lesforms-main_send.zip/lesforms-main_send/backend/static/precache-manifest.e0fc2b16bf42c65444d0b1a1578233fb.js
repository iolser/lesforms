self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "6df6e26ec5471fd20843",
    "url": "/static/css/app.0f6f6e19.css"
  },
  {
    "revision": "80d4cd15aa4781c57a87b58aad650305",
    "url": "/static/index.html"
  },
  {
    "revision": "6df6e26ec5471fd20843",
    "url": "/static/js/app.1f3fed6f.js"
  },
  {
    "revision": "0d6dd6e592290e7fe927",
    "url": "/static/js/chunk-vendors.d54be52e.js"
  },
  {
    "revision": "4b14c64efaf846819b9a229b4193c8b7",
    "url": "/static/manifest.json"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "/static/robots.txt"
  }
]);