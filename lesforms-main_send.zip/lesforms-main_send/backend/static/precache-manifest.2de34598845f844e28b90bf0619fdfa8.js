self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "ae7b4f48a068dab8b196",
    "url": "/static/css/chunk-0a0740b2.4c9fe055.css"
  },
  {
    "revision": "fc4a42f9f902a95cfffa",
    "url": "/static/css/chunk-1ac67b5a.bbcbc325.css"
  },
  {
    "revision": "9db4b27ee02a5107c32e",
    "url": "/static/css/chunk-28da5a7e.fc8cdf04.css"
  },
  {
    "revision": "3594c95eae8da9b44c5e",
    "url": "/static/css/chunk-4bec4152.f7c6d4fc.css"
  },
  {
    "revision": "c11dc8aee4691487366a",
    "url": "/static/css/chunk-93d79998.ad833cf5.css"
  },
  {
    "revision": "2fad916ae631aca46bb9",
    "url": "/static/css/chunk-96a24e48.b37314ce.css"
  },
  {
    "revision": "662a091670034b8a2f72",
    "url": "/static/css/chunk-be0d0ef6.efab6de7.css"
  },
  {
    "revision": "fa43b5ea1f485cdc140a",
    "url": "/static/css/chunk-e9227fc4.f1aa5b7a.css"
  },
  {
    "revision": "c351805a659e633173a3c19b5f8c7a5e",
    "url": "/static/img/ualg.c351805a.svg"
  },
  {
    "revision": "e5ee1ce0992900d1a4e5b6fea03569a4",
    "url": "/static/index.html"
  },
  {
    "revision": "28f669b86a48b1a3f2fe",
    "url": "/static/js/app.e3126ff7.js"
  },
  {
    "revision": "ae7b4f48a068dab8b196",
    "url": "/static/js/chunk-0a0740b2.39395d80.js"
  },
  {
    "revision": "fc4a42f9f902a95cfffa",
    "url": "/static/js/chunk-1ac67b5a.3c1c07ce.js"
  },
  {
    "revision": "ad52e8171a6e0c3166a1",
    "url": "/static/js/chunk-25b209d3.fb12a630.js"
  },
  {
    "revision": "9db4b27ee02a5107c32e",
    "url": "/static/js/chunk-28da5a7e.cf22e34d.js"
  },
  {
    "revision": "c1d80daa84a44686c700",
    "url": "/static/js/chunk-299460f9.5b536863.js"
  },
  {
    "revision": "ade1101929c537d52f63",
    "url": "/static/js/chunk-2c231cbe.4984facc.js"
  },
  {
    "revision": "73775a3b81ad674f64d4",
    "url": "/static/js/chunk-2d0ab358.82574c9f.js"
  },
  {
    "revision": "b28913d3f1b19c68a1a9",
    "url": "/static/js/chunk-2d0b688d.56f19d4a.js"
  },
  {
    "revision": "8f9d4e232bff9de9dab5",
    "url": "/static/js/chunk-2d0b6994.a3b39048.js"
  },
  {
    "revision": "d16639a6cf0c01b13798",
    "url": "/static/js/chunk-2d0ba938.e96417fb.js"
  },
  {
    "revision": "3508a554a24909fdfb3c",
    "url": "/static/js/chunk-2d0dd08b.e0cf213f.js"
  },
  {
    "revision": "f997b21a52255676ac59",
    "url": "/static/js/chunk-2d0e4545.d4ed24aa.js"
  },
  {
    "revision": "6d37405af8413d5156fa",
    "url": "/static/js/chunk-2d20918a.9fcb47f0.js"
  },
  {
    "revision": "ba27e145586ca5bbac1d",
    "url": "/static/js/chunk-2d2178d7.84962fd4.js"
  },
  {
    "revision": "eec61f0b114f980b06ca",
    "url": "/static/js/chunk-2d229bf0.62f638aa.js"
  },
  {
    "revision": "3594c95eae8da9b44c5e",
    "url": "/static/js/chunk-4bec4152.57e9d438.js"
  },
  {
    "revision": "c11dc8aee4691487366a",
    "url": "/static/js/chunk-93d79998.9a314d07.js"
  },
  {
    "revision": "2fad916ae631aca46bb9",
    "url": "/static/js/chunk-96a24e48.def01b33.js"
  },
  {
    "revision": "662a091670034b8a2f72",
    "url": "/static/js/chunk-be0d0ef6.e1935b2a.js"
  },
  {
    "revision": "fa43b5ea1f485cdc140a",
    "url": "/static/js/chunk-e9227fc4.002fd88b.js"
  },
  {
    "revision": "f29f993d451f9283699d",
    "url": "/static/js/chunk-ef5c54ee.db067e43.js"
  },
  {
    "revision": "04fbb2a1083e77971120",
    "url": "/static/js/chunk-vendors.cb167ed6.js"
  },
  {
    "revision": "4b14c64efaf846819b9a229b4193c8b7",
    "url": "/static/manifest.json"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "/static/robots.txt"
  }
]);