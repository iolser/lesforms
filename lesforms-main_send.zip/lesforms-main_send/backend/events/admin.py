from django.contrib import admin

from resources.models import Event

# Register your models here.