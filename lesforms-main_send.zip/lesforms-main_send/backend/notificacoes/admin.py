from django.contrib import admin
from .models import *
# Register your models here.

# admin.site.register(NotificacaoAutomatica)
# admin.site.register(Notificacao)
# admin.site.register(Mensagem)

